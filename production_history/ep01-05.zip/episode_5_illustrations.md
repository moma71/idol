# Episode 5 Illustrations

## 🎨 Scene 1: Opening - 평가 대기줄
**NovelAI Prompt:**
```
Training center hallway, 12 young women in line,
poster on wall "중간 평가 D-15",
nervous atmosphere, morning 9 AM,
Korean webtoon style, --ar 16:9
```

## 🎨 Scene 2: MIRA 평가 ⭐ HIGHEST
**NovelAI Prompt:**
```
Evaluation room, three judges sitting at table,
young woman (MIRA, ponytail) singing center stage,
focused expression, stage lighting,
judges watching attentively,
Korean webtoon style, --ar 2:3
```

## 🎨 Scene 3: ARIN 평가 ⭐ HIGH
**NovelAI Prompt:**
```
Evaluation room, blonde woman dancing,
precise movements, confident expression,
judges nodding approval,
Korean webtoon style, --ar 16:9
```

## 🎨 Scene 4: CHAEWON 대기
**NovelAI Prompt:**
```
Hallway outside evaluation room,
woman (CHAEWON) standing alone nervous,
touching bandaged fingers but not biting,
contemplative expression,
Korean webtoon style, --ar 2:3
```

## 🎨 Scene 5: CHAEWON 평가
**NovelAI Prompt:**
```
Evaluation room, woman (CHAEWON) singing,
sweat on face but focused expression,
5-year trainee determination visible,
Korean webtoon style, --ar 16:9
```

## 🎨 Scene 6: Ending - 세 사람 함께 ⭐ HIGHEST
**NovelAI Prompt:**
```
Dormitory room night, three women sitting on bed together,
looking at phones showing ChatGPT,
MIRA teaching, ARIN supporting, CHAEWON learning,
warm lighting, collaborative atmosphere,
Korean webtoon style, --ar 16:9
```

## 📊 Priority: 2 → 6 → 3 → 5 → 4 → 1
