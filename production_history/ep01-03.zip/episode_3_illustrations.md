# Episode 3 Illustrations

## 🎨 Scene 1: Opening - Week 1 완료 메모
**NovelAI Prompt:**
```
Close-up of notebook page with Korean text "Week 1 완료!",
checkmarks and dense handwriting visible,
pen beside notebook, training room background blurred,
Korean webtoon style, --ar 16:9
```

## 🎨 Scene 2: 트레이너 피드백 ⭐ HIGH
**NovelAI Prompt:**
```
Training room corner, male trainer (30s) holding tablet,
young woman (MIRA, ponytail) standing nervously listening,
trainer smiling, MIRA surprised expression,
morning light, professional atmosphere,
Korean webtoon style, --ar 2:3
```

## 🎨 Scene 3: MIRA와 Claude
**NovelAI Prompt:**
```
Training room afternoon, woman sitting on floor,
looking at phone showing Claude interface with analysis table,
notebook open beside with notes,
concentrated expression,
Korean webtoon style, --ar 2:3
```

## 🎨 Scene 4: ARIN 등장 ⭐ HIGHEST
**NovelAI Prompt:**
```
Two women sitting together on training room floor,
first: ponytail showing phone, second: blonde showing checklist,
both smiling, collaborative mood,
Nike athletic wear, afternoon light,
Korean webtoon style, --ar 16:9
```

## 🎨 Scene 5: CHAEWON 관찰
**NovelAI Prompt:**
```
Woman (CHAEWON, long black hair) standing in doorway,
looking at two women inside room through door gap,
holding 2L water bottle and candy case,
worried expression, bitten nails visible,
Korean webtoon style, --ar 2:3
```

## 🎨 Scene 6: Ending - 메모 노트
**NovelAI Prompt:**
```
Notebook close-up showing "Week 2 목표" in Korean,
two different handwritings visible,
one neat, one with "ㅇㅈ" note,
dormitory bed background blurred,
warm night lighting,
Korean webtoon style, --ar 16:9
```

## 📊 Priority: 4 → 2 → 5 → 6 → 3 → 1
