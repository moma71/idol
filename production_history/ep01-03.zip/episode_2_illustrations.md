# Episode 2 Illustrations

## 🎨 Scene 1: Opening - 새벽 복도 마주침
**NovelAI Prompt:**
```
Two young women facing each other in hallway at dawn,
first: round face, ponytail, white t-shirt with sweat, holding notebook,
second: blonde hair, cat eyes, Nike crop top, AirPods,
suspicious atmosphere,
Korean webtoon style, --ar 16:9
```

## 🎨 Scene 2: 연습실 - ARIN 관찰 ⭐ HIGH
**NovelAI Prompt:**
```
Training room, woman practicing vocals center,
blonde woman in doorway watching intently, AirPods removed,
mirror reflection showing both,
morning 10 AM,
Korean webtoon style, --ar 2:3
```

## 🎨 Scene 3: 식당 - CHAEWON 대화
**NovelAI Prompt:**
```
Cafeteria lunch time,
two women at table, first: long black hair holding candy case,
second: ponytail nervous with spoon,
2L water bottle visible,
Korean webtoon style, --ar 16:9
```

## 🎨 Scene 4: 연습실 - ChatGPT
**NovelAI Prompt:**
```
Empty training room evening,
woman on floor looking at phone showing ChatGPT,
notebook beside with notes,
contemplative mood,
Korean webtoon style, --ar 2:3
```

## 🎨 Scene 5: "Please?" ⭐ HIGHEST
**NovelAI Prompt:**
```
Training room doorway evening,
blonde woman at door serious expression showing vulnerability,
facing shorter woman with notebook,
genuine curiosity in eyes,
Korean webtoon style, --ar 2:3
```

## 🎨 Scene 6: Ending - 나란히
**NovelAI Prompt:**
```
Hallway night,
two women walking together,
one showing notebook, other looking at phone,
collaborative atmosphere,
Korean webtoon style, --ar 16:9
```

## 📊 Priority: 5 → 2 → 6 → 1 → 4 → 3
