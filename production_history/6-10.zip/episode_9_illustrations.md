# Episode 9 Illustrations

## 🎨 Scene 1: Opening - D-7 알림
**NovelAI Prompt:**
```
Close-up phone screen showing alarm,
"최종 평가 D-7일" notification visible,
MIRA's hand holding phone, nervous atmosphere,
morning light,
Korean webtoon style, --ar 2:3
```

## 🎨 Scene 2: 12명 전체 회의 ⭐ HIGH
**NovelAI Prompt:**
```
Training room, 12 women sitting in circle,
notebooks and phones in center, serious discussion,
MIRA explaining with Claude screen visible,
teamwork atmosphere,
Korean webtoon style, --ar 16:9
```

## 🎨 Scene 3: 개인 연습 ⭐ HIGH
**NovelAI Prompt:**
```
Training room afternoon, 12 women practicing separately,
MIRA rapping with metronome, ARIN dancing,
CHAEWON singing, everyone focused,
dedicated atmosphere,
Korean webtoon style, --ar 16:9
```

## 🎨 Scene 4: 트레이너 대화 ⭐ HIGHEST
**NovelAI Prompt:**
```
Hallway evening, male trainer talking to MIRA,
encouraging expression, MIRA looking shy,
supportive conversation atmosphere,
Korean webtoon style, --ar 2:3
```

## 🎨 Scene 5: 단톡방 인증샷
**NovelAI Prompt:**
```
Phone screen showing group chat flood,
12 proof photos scrolling, various activities,
enthusiastic messages, night 9 PM,
Korean webtoon style, --ar 2:3
```

## 🎨 Scene 6: Ending - D-6 아침
**NovelAI Prompt:**
```
Dormitory hallway dawn, 12 women walking together,
determined expressions, sunrise light,
united team atmosphere,
Korean webtoon style, --ar 16:9
```

## 📊 Priority: 4 → 2 → 3 → 6 → 1 → 5
