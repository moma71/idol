# Episode 6 Illustrations

## 🎨 Scene 1: Opening - 새벽 5시 셋 ⭐ HIGH
**NovelAI Prompt:**
```
Training room dawn 5 AM, three women stretching together,
MIRA (ponytail), ARIN (blonde), CHAEWON (long hair),
sunrise light through window, peaceful atmosphere,
Korean webtoon style, --ar 16:9
```

## 🎨 Scene 2: MIRA 랩 연습
**NovelAI Prompt:**
```
Woman (MIRA) practicing rap with metronome,
phone recording on tripod, sweat dripping,
concentrated expression, morning 10 AM,
Korean webtoon style, --ar 2:3
```

## 🎨 Scene 3: 식당 다섯 명 ⭐ HIGHEST
**NovelAI Prompt:**
```
Cafeteria table, five women sitting together,
five phones on table showing ChatGPT,
MIRA teaching, others learning,
collaborative atmosphere, lunch time,
Korean webtoon style, --ar 16:9
```

## 🎨 Scene 4: 팀 회의
**NovelAI Prompt:**
```
Training room evening, five women sitting in circle,
notebooks and phones in center,
serious discussion, teamwork atmosphere,
Korean webtoon style, --ar 16:9
```

## 🎨 Scene 5: 복도 - 다른 연습생들
**NovelAI Prompt:**
```
Hallway night, three other trainees whispering,
looking at MIRA's team of five walking away,
jealous and curious expressions,
Korean webtoon style, --ar 2:3
```

## 🎨 Scene 6: Ending - 기숙사 밤 ⭐ HIGH
**NovelAI Prompt:**
```
Dormitory room night, four women in beds,
all looking at phones showing ChatGPT/Claude,
warm bedside lights, peaceful studying atmosphere,
Korean webtoon style, --ar 16:9
```

## 📊 Priority: 3 → 6 → 1 → 4 → 2 → 5
