# Episode 7 Illustrations

## 🎨 Scene 1: Opening - 좌절 ⭐ HIGHEST
**NovelAI Prompt:**
```
Training room, woman (MIRA) sitting on floor defeated,
metronome in front still ticking,
frustrated expression, sweat and tears,
morning 10 AM harsh lighting,
Korean webtoon style, --ar 2:3
```

## 🎨 Scene 2: 복도 - CHAEWON 위로
**NovelAI Prompt:**
```
Hallway, two women talking,
CHAEWON holding water bottle comforting MIRA,
MIRA leaning against wall looking tired,
supportive atmosphere,
Korean webtoon style, --ar 16:9
```

## 🎨 Scene 3: 공원 산책 ⭐ HIGH
**NovelAI Prompt:**
```
Park bench afternoon, MIRA sitting alone peaceful,
trees and sunlight, birds flying,
ARIN joining with convenience store bag,
healing atmosphere,
Korean webtoon style, --ar 16:9
```

## 🎨 Scene 4: 기숙사 파티
**NovelAI Prompt:**
```
Dormitory room evening, five women sitting together,
pizza boxes and cola on floor,
laughing and talking, supportive friends,
warm lighting,
Korean webtoon style, --ar 16:9
```

## 🎨 Scene 5: ChatGPT 회복 계획
**NovelAI Prompt:**
```
Close-up phone screen showing ChatGPT recovery plan,
"24시간 회복 계획" visible,
MIRA's hand holding phone,
Korean webtoon style, --ar 2:3
```

## 🎨 Scene 6: Ending - 재시작 ⭐ HIGHEST
**NovelAI Prompt:**
```
Training room next morning dawn,
MIRA in front of metronome confident expression,
BPM 120 visible, fresh start atmosphere,
hopeful lighting,
Korean webtoon style, --ar 2:3
```

## 📊 Priority: 1 → 6 → 3 → 4 → 2 → 5
