# Episode 10 Illustrations

## 🎨 Scene 1: Opening - D-Day 아침 ⭐ HIGHEST
**NovelAI Prompt:**
```
Dormitory room dawn, MIRA waking up,
sunrise through window, notebook open,
"D-30 → D-0" visible, historic moment,
hopeful atmosphere,
Korean webtoon style, --ar 2:3
```

## 🎨 Scene 2: 12명 출발 ⭐ HIGH
**NovelAI Prompt:**
```
Dormitory hallway, 12 women in evaluation uniforms,
hands together in center circle, team unity,
determined expressions, morning light,
Korean webtoon style, --ar 16:9
```

## 🎨 Scene 3: MIRA 평가 ⭐ HIGHEST
**NovelAI Prompt:**
```
Evaluation room, MIRA performing center stage,
5 judges watching including JYP founder,
spotlight on MIRA, concentrated expression,
sweat and determination,
Korean webtoon style, --ar 2:3
```

## 🎨 Scene 4: 복도 축하 ⭐ HIGHEST
**NovelAI Prompt:**
```
Hallway outside evaluation room,
11 women hugging crying MIRA,
tears of joy, celebration atmosphere,
emotional moment,
Korean webtoon style, --ar 16:9
```

## 🎨 Scene 5: 5명 데뷔 확정
**NovelAI Prompt:**
```
Evaluation room, 5 women standing front,
MIRA, ARIN, CHAEWON, LUNA, REI,
JYP PD congratulating, other 7 applauding,
bittersweet atmosphere,
Korean webtoon style, --ar 16:9
```

## 🎨 Scene 6: Ending - 메모 노트 ⭐ HIGHEST
**NovelAI Prompt:**
```
Close-up notebook pages,
"D-30: 74점" → "D-0: 82점" visible,
dense notes and plans throughout,
MIRA's hand holding pen,
4-week journey documented,
Korean webtoon style, --ar 2:3
```

## 📊 Priority: 1 → 3 → 4 → 6 → 5 → 2
