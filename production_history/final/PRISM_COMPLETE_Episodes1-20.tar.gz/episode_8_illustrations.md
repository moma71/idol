# Episode 8 Illustrations

## 🎨 Scene 1: Opening - 12명 모임 ⭐ HIGHEST
**NovelAI Prompt:**
```
Training room evening, 12 young women gathered,
5 standing front (MIRA team), 7 sitting floor,
classroom-like setup, educational atmosphere,
Korean webtoon style, --ar 16:9
```

## 🎨 Scene 2: Tutorial 세션 ⭐ HIGH
**NovelAI Prompt:**
```
Training room, MIRA at whiteboard explaining,
12 women holding phones looking at ChatGPT,
focused learning atmosphere, evening 8:30 PM,
Korean webtoon style, --ar 16:9
```

## 🎨 Scene 3: 단톡방 화면
**NovelAI Prompt:**
```
Close-up phone screen showing group chat,
"JYP 연습생 AI 스터디" title visible,
12 participants, messages flowing,
Korean webtoon style, --ar 2:3
```

## 🎨 Scene 4: 다음 날 새벽 12명 ⭐ HIGHEST
**NovelAI Prompt:**
```
Training room dawn 5 AM, 12 women all practicing together,
various activities (vocal, dance, rap),
everyone with phones, united atmosphere,
sunrise light through window,
Korean webtoon style, --ar 16:9
```

## 🎨 Scene 5: 인증샷 올리기
**NovelAI Prompt:**
```
Phone screen montage showing 12 proof photos,
ChatGPT screens, exercise videos, notebooks,
group chat with enthusiastic messages,
Korean webtoon style, --ar 2:3
```

## 🎨 Scene 6: Ending - MIRA 뿌듯함
**NovelAI Prompt:**
```
Dormitory bed night, MIRA lying down looking at phone,
satisfied smile, phone showing group chat success,
warm bedside light,
Korean webtoon style, --ar 2:3
```

## 📊 Priority: 1 → 4 → 2 → 6 → 3 → 5
