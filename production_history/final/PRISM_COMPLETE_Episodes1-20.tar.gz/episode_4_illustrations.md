# Episode 4 Illustrations

## 🎨 Scene 1: Opening - CHAEWON 혼자 연습 ⭐ HIGHEST
**NovelAI Prompt:**
```
Empty training room 3 AM, woman (26, long black hair) practicing alone,
exhausted expression, gray t-shirt soaked with sweat,
2L water bottle and candy case on floor,
mirror reflection showing tired face,
dark atmosphere with single spotlight,
Korean webtoon style, --ar 16:9
```

## 🎨 Scene 2: 식당 - 대조
**NovelAI Prompt:**
```
Training center cafeteria morning,
four young women at table laughing together,
one woman (CHAEWON) alone at corner table background,
contrast between group and isolation,
Korean webtoon style, --ar 16:9
```

## 🎨 Scene 3: 복도 - CHAEWON 쓰러짐 ⭐ HIGH
**NovelAI Prompt:**
```
Hallway, woman (CHAEWON) leaning against wall looking faint,
pale face with cold sweat,
bitten nails visible,
another woman (MIRA, ponytail) running to help,
morning light, concerned atmosphere,
Korean webtoon style, --ar 2:3
```

## 🎨 Scene 4: ChatGPT 결과
**NovelAI Prompt:**
```
Two women sitting on training room floor,
both looking at phone together showing ChatGPT mental care guide,
serious expressions, afternoon light,
Korean webtoon style, --ar 16:9
```

## 🎨 Scene 5: 복도 - CHAEWON 홀로
**NovelAI Prompt:**
```
Empty hallway evening 9 PM,
woman (CHAEWON) leaning against wall holding phone,
screen off, contemplative mood,
bandage on finger visible,
lonely atmosphere with corridor lights,
Korean webtoon style, --ar 2:3
```

## 🎨 Scene 6: Ending - 세 사람 ⭐ HIGH
**NovelAI Prompt:**
```
Hallway night, three women standing together,
CHAEWON drinking water bottle, MIRA and ARIN beside her,
supportive atmosphere, gentle smiles,
warm corridor lighting,
Korean webtoon style, --ar 16:9
```

## 📊 Priority: 1 → 3 → 6 → 5 → 2 → 4
